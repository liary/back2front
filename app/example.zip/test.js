
console.log(process.env)
